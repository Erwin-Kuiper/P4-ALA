<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="language" content="NL">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="ALA, Project">
        <meta name="author" content="Erwin Kuiper, Wim van der Linde">
        <meta name="keywords" content="ALA, HTML, CSS, JavaScript, PHP, SQL">
        <link rel="stylesheet" type="text/css" href="CSS/CSS.css">
        <script src="JavaScript/Script.js" type="text/javascript"></script>
        <title>P4 ALA - Website - Empty PHP 3</title>
    </head>

    <body>

    </body>

</html>